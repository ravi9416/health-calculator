# Health-Calculator

<p align="center">
<p>Demo</p>
  <img src="https://github.com/ibnahmadbello/Health-Calculator/blob/master/demo/second.gif" width="30%">
</p>
